INTENSIDAD = 0.5

NPoi <- function(x,a,b) {
  return (dpois(x,(b-a)*INTENSIDAD))
}

GPoi <- function(x,k) {
  return (dgamma(x,k,INTENSIDAD))
}


x <- c(1:10)
res <- 0
for (val in x) {
  res = res + GPoi(val,2)
}
1-res
6*exp(-5)
NPoi(0,0,10)+NPoi(1,0,10)